// The following is a result of an analysis of the letters occurring
// in the words listed in the main entries of the Concise Oxford Dictionary (9th edition, 1995)
// https://www3.nd.edu/~busiforc/handouts/cryptography/letterfrequencies.html
export const letterFrequency =
    [
        {key: 'A', p: 	8.4966},
        {key: 'B', p: 	2.0720},
        {key: 'C', p: 	4.5388},
        {key: 'D', p: 	3.3844},
        {key: 'E', p: 	11.1607},
        {key: 'F', p: 	1.8121},
        {key: 'G', p: 	2.4705},
        {key: 'H', p: 	3.0034},
        {key: 'I', p: 	7.5448},
        {key: 'J', p: 	0.1965},
        {key: 'K', p: 	1.1016},
        {key: 'L', p: 	5.4893},
        {key: 'M', p: 	3.01296},
        {key: 'N', p: 	6.6544},
        {key: 'O', p: 	7.1635},
        {key: 'P', p: 	3.1671},
        {key: 'Q', p: 	0.1962},
        {key: 'R', p: 	7.5809},
        {key: 'S', p: 	5.7351},
        {key: 'T', p: 	6.9509},
        {key: 'U', p: 	3.6308},
        {key: 'V', p: 	1.0074},
        {key: 'W', p: 	1.2899},
        {key: 'X', p: 	0.2902},
        {key: 'Y', p: 	1.7779},
        {key: 'Z', p: 	0.2722},
    ];
